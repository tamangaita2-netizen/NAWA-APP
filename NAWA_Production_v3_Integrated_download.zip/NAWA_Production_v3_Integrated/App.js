import React from "react";
import {SafeAreaView,View,Text,StyleSheet,Pressable} from "react-native";
export default function App(){
 return <SafeAreaView style={s.safe}><View style={s.page}>
  <Text style={s.logo}>NAWA</Text>
  <View style={s.center}><Text style={s.title}>NAWA Short Video</Text>
  <Text style={s.sub}>Create • Discover • Remix • Connect</Text>
  <Pressable style={s.btn}><Text style={s.bt}>＋ Create Video</Text></Pressable></View>
  <View style={s.tabs}>{["Home","Discover","＋","Inbox","Profile"].map(x=><Text key={x} style={s.tab}>{x}</Text>)}</View>
 </View></SafeAreaView>
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:"#050505"},page:{flex:1,justifyContent:"space-between",padding:18},logo:{color:"#fff",fontSize:28,fontWeight:"800"},center:{alignItems:"center"},title:{color:"#fff",fontSize:24,fontWeight:"700"},sub:{color:"#bbb",marginTop:8},btn:{marginTop:22,padding:14,paddingHorizontal:22,borderRadius:25,backgroundColor:"#fff"},bt:{color:"#000",fontWeight:"700"},tabs:{flexDirection:"row",justifyContent:"space-between"},tab:{color:"#fff",fontSize:13}});
